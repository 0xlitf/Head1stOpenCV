#pragma once
#include "HalconCpp.h"

using namespace Halcon;


// Procedure declarations 
void search_shape_model(Halcon::Hobject ImageNew, Halcon::Hobject RegionROI, Halcon::Hobject ModelRegionsOrigins,
    Halcon::HTuple WindowHandle, Halcon::HTuple ModelIDs, Halcon::HTuple Threshold,
    Halcon::HTuple WdiffValue, Halcon::HTuple MinScore, Halcon::HTuple MinDefectInnerRadian,
    Halcon::HTuple* NewRow, Halcon::HTuple* NewColumn, Halcon::HTuple* NewWidth,
    Halcon::HTuple* NewArea, Halcon::HTuple* Result);

void generate_shape_model(Halcon::Hobject ImageModel, Halcon::Hobject RegionROI,
    Halcon::Hobject* ModelRegionsOrigin, Halcon::HTuple WindowHandle, Halcon::HTuple ModelWidthAll,
    Halcon::HTuple ModelHeightAll, Halcon::HTuple Threshold, Halcon::HTuple* ModelID,
    Halcon::HTuple* ModelWidth, Halcon::HTuple* ModelHeight, Halcon::HTuple* ModelArea,
    Halcon::HTuple* isTrained);

void generate_shape_model_dynamic(Halcon::Hobject ImageModel, Halcon::Hobject RegionROI,
	Halcon::Hobject ModelRegions, Halcon::Hobject *ModelRegionsOrigin, Halcon::HTuple WindowHandle,
	Halcon::HTuple ModelIDs, Halcon::HTuple ModelWidthAll, Halcon::HTuple ModelHeightAll,
	Halcon::HTuple ModelGrays, Halcon::HTuple Threshold, Halcon::HTuple WdiffValue,
	Halcon::HTuple IsDynamic, Halcon::HTuple *ModelID, Halcon::HTuple *ModelWidth,
	Halcon::HTuple *ModelHeight, Halcon::HTuple *ModelArea, Halcon::HTuple *ModelGrayVal,
	Halcon::HTuple *isTrained);

void search_shape_model_gray(Halcon::Hobject ImageNew, Halcon::Hobject RegionROI,
	Halcon::Hobject ModelRegionsOrigins, Halcon::Hobject *ObjRegions, Halcon::HTuple WindowHandle,
	Halcon::HTuple ModelIDs, Halcon::HTuple ModelGrays, Halcon::HTuple Threshold,
	Halcon::HTuple WdiffValue, Halcon::HTuple MinScore, Halcon::HTuple MinDefectInnerRadian,
	Halcon::HTuple *NewRow, Halcon::HTuple *NewColumn, Halcon::HTuple *NewWidth,
	Halcon::HTuple *NewArea, Halcon::HTuple *Model, Halcon::HTuple *Result);

// Chapter: Graphics / Text
// Short Description: This procedure writes a text message.
void disp_message(Halcon::HTuple WindowHandle, Halcon::HTuple String, Halcon::HTuple CoordSystem,
    Halcon::HTuple Row, Halcon::HTuple Column, Halcon::HTuple Color, Halcon::HTuple Box);

void segment_color(Halcon::Hobject ImageNew, Halcon::Hobject *ImageSegment, Halcon::Hobject *ObjRegion,
	Halcon::HTuple WindowHandle, Halcon::HTuple Threshold);

void get_calib_factor(Halcon::Hobject ImageCalib, Halcon::HTuple *scale_factor);

void circle_detector(Halcon::Hobject Image, Halcon::Hobject *ImageSegment, Halcon::Hobject *ObjRegion,
	Halcon::HTuple WindowHandle, Halcon::HTuple MinDefectInnerRadian, Halcon::HTuple MinDefectArea,
	Halcon::HTuple ThreshDark, Halcon::HTuple ThreshLight, Halcon::HTuple *isDefect);